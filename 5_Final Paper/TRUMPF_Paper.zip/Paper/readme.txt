This is a template for project papers at the Mobile and Distributed Systems
group at the LMU Munich. For question regarding this template, you can drop an
email to: jonas.stein@ifi.lmu.de

To use this template, do the following:
- Edit the file contents.tex to include your thesis.
- Edit the file references.bib to contain your BibTeX references.
- Edit the file config.tex so that it contains your data!
- Compile the file index.tex with pdflatex and bibtex.
- The then created file index.pdf will contain your project thesis!